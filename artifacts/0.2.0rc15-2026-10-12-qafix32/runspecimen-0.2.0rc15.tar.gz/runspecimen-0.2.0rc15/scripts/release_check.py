#!/usr/bin/env python3
"""Test, build, and smoke-test distributable releases without network access.

Build tools must already be installed (see bootstrap_dev.sh). All packaging and
CLI work happens in temporary directories. Use --output-dir to retain the
validated wheel, source archive, plugin ZIP, report, and SHA-256 checksums.
"""

from __future__ import annotations

import argparse
import gzip
import importlib.util
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import urllib.error
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath


ROOT = Path(__file__).resolve().parents[1]
EXPECTED_PYTHON_VERSION = "0.2.0rc15"
EXPECTED_PLUGIN_VERSION = "0.2.0-rc.15"
# Fixed metadata clock for release archives. Wall-clock gzip, tar, and zip
# timestamps otherwise change the archive bytes on every build. 2020-01-01 UTC
# matches the plugin zip and is representable in zip (dates before 1980 are not).
ARCHIVE_MTIME = 1577836800
ARCHIVE_ZIP_DATE = (2020, 1, 1, 0, 0, 0)
# Reproducible-builds gzip convention: header mtime 0, no original filename.
GZIP_MTIME = 0
SOURCE_COMPONENTS = (
    "pyproject.toml", "MANIFEST.in", "README.md", "LICENSE", "CHANGELOG.md",
    "SECURITY.md", "src", "scripts", "tests", "docs", "examples", "work",
    "packaging", "plugins", ".cursor", ".cursor-plugin", ".claude-plugin",
    ".junie-extension", ".agents",
)
PLUGIN_COMPONENTS = (
    ".codex-plugin/plugin.json", ".cursor-plugin/plugin.json",
    ".claude-plugin/plugin.json", "gemini-extension.json", "extension.json",
    ".mcp.json", "mcp/.mcp.json", "GEMINI.md", "README.md",
    "assets/logo.png",
    "assets/composer-icon.png",
    "assets/logo.svg",
    "assets/composer-icon.svg",
    "rules/runspecimen.mdc", "scripts/runspecimen_adapter.py",
    "scripts/block_approve_gate.py", "scripts/runspecimen_mcp.py",
    "hooks/hooks.json", "hooks/claude-hooks.json", "skills/runspecimen/SKILL.md",
    "commands/request-approval.md", "commands/request-approval.toml",
    "grok/README.md", "grok/AGENTS.md",
    "gemini/README.md", "jetbrains/README.md",
    "jetbrains/scripts/ide_actions.py",
    "windsurf/README.md", "windsurf/skills/runspecimen/SKILL.md",
    "windsurf/rules/runspecimen.md",
    "guidelines/runspecimen.md",
    "antigravity/plugin.json", "antigravity/mcp_config.json",
    "antigravity/hooks.json", "antigravity/README.md",
    "antigravity/skills/runspecimen/SKILL.md",
    "antigravity/rules/runspecimen.md",
    "antigravity/scripts/block_approve_gate.py",
    "antigravity/scripts/runspecimen_mcp.py",
    "muse/README.md", "muse/skills/runspecimen/SKILL.md",
    "muse/examples/mcp_settings.fragment.json",
    "muse/examples/hooks.beta.json",
)
FORBIDDEN_PARTS = frozenset({".git", ".runspecimen", ".tools", "__pycache__"})


def run(*args: str, cwd: Path = ROOT, env: dict[str, str] | None = None,
        capture: bool = False, timeout: int = 300) -> subprocess.CompletedProcess[str]:
    print("+", " ".join(args), flush=True)
    return subprocess.run(
        args, cwd=cwd, env=env, check=True, text=True,
        stdin=subprocess.DEVNULL, capture_output=capture, timeout=timeout,
    )


def _load_script_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise SystemExit(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def check_versions() -> None:
    for relative, pattern in (
        ("pyproject.toml", r'^version = "([^"]+)"$'),
        ("src/runspecimen/__init__.py", r'^__version__ = "([^"]+)"$'),
    ):
        match = re.search(pattern, (ROOT / relative).read_text(encoding="utf-8"), re.MULTILINE)
        if match is None or match.group(1) != EXPECTED_PYTHON_VERSION:
            raise SystemExit(f"{relative} version does not match release_check.py")
    plugin_root = ROOT / "plugins/runspecimen"
    plugin = json.loads((plugin_root / ".codex-plugin/plugin.json").read_text(encoding="utf-8"))
    cursor = json.loads((plugin_root / ".cursor-plugin/plugin.json").read_text(encoding="utf-8"))
    claude = json.loads((plugin_root / ".claude-plugin/plugin.json").read_text(encoding="utf-8"))
    gemini = json.loads((plugin_root / "gemini-extension.json").read_text(encoding="utf-8"))
    if plugin.get("version", "").split("+", 1)[0] != EXPECTED_PLUGIN_VERSION:
        raise SystemExit("Codex plugin version does not match release_check.py")
    if cursor.get("version") != EXPECTED_PLUGIN_VERSION or cursor.get("name") != plugin.get("name"):
        raise SystemExit("Cursor plugin version/name is inconsistent")
    if claude.get("version") != EXPECTED_PLUGIN_VERSION or claude.get("name") != plugin.get("name"):
        raise SystemExit("Claude plugin version/name is inconsistent")
    if gemini.get("version") != EXPECTED_PLUGIN_VERSION or gemini.get("name") != plugin.get("name"):
        raise SystemExit("Gemini extension version/name is inconsistent")
    if "approve" not in " ".join(gemini.get("excludeTools") or []).lower():
        raise SystemExit("Gemini extension must exclude approve-like shell tools")
    prompts = plugin.get("interface", {}).get("defaultPrompt")
    if not isinstance(prompts, list) or not prompts or not all(
        isinstance(item, str) and item for item in prompts
    ):
        raise SystemExit("Codex plugin defaultPrompt must be a non-empty string array")
    marketplace = json.loads((ROOT / ".cursor-plugin/marketplace.json").read_text(encoding="utf-8"))
    entries = marketplace.get("plugins")
    if not isinstance(entries, list) or len(entries) != 1:
        raise SystemExit("Cursor marketplace must contain exactly the RunSpecimen plugin")
    if any(entries[0].get(key) != value for key, value in (
        ("name", "runspecimen"), ("source", "plugins/runspecimen"),
        ("version", EXPECTED_PLUGIN_VERSION),
    )):
        raise SystemExit("Cursor marketplace entry is inconsistent")
    claude_market = json.loads((ROOT / ".claude-plugin/marketplace.json").read_text(encoding="utf-8"))
    claude_entries = claude_market.get("plugins")
    if not isinstance(claude_entries, list) or len(claude_entries) != 1:
        raise SystemExit("Claude marketplace must contain exactly the RunSpecimen plugin")
    if any(claude_entries[0].get(key) != value for key, value in (
        ("name", "runspecimen"), ("source", "./plugins/runspecimen"),
        ("version", EXPECTED_PLUGIN_VERSION),
    )):
        raise SystemExit("Claude marketplace entry is inconsistent")
    junie_market = json.loads((ROOT / ".junie-extension/marketplace.json").read_text(encoding="utf-8"))
    junie_entries = junie_market.get("extensions")
    if not isinstance(junie_entries, list) or len(junie_entries) != 1:
        raise SystemExit("Junie marketplace must contain exactly the RunSpecimen extension")
    if any(junie_entries[0].get(key) != value for key, value in (
        ("name", "runspecimen"), ("source", "./plugins/runspecimen"),
        ("version", EXPECTED_PLUGIN_VERSION),
    )):
        raise SystemExit("Junie marketplace entry is inconsistent")
    mcp = json.loads((plugin_root / ".mcp.json").read_text(encoding="utf-8"))
    if "runspecimen" not in (mcp.get("mcpServers") or {}):
        raise SystemExit("plugin .mcp.json must declare runspecimen server")
    junie_mcp = json.loads((plugin_root / "mcp/.mcp.json").read_text(encoding="utf-8"))
    if "runspecimen" not in (junie_mcp.get("mcpServers") or {}):
        raise SystemExit("plugin mcp/.mcp.json must declare runspecimen server")
    hooks = json.loads((plugin_root / "hooks/hooks.json").read_text(encoding="utf-8"))
    if "BeforeTool" not in (hooks.get("hooks") or {}) or "PreToolUse" in (hooks.get("hooks") or {}):
        raise SystemExit("hooks/hooks.json must be Gemini BeforeTool-only (Claude rejects BeforeTool)")
    claude_hooks = json.loads((plugin_root / "hooks/claude-hooks.json").read_text(encoding="utf-8"))
    if "PreToolUse" not in (claude_hooks.get("hooks") or {}) or "BeforeTool" in (claude_hooks.get("hooks") or {}):
        raise SystemExit("hooks/claude-hooks.json must be Claude PreToolUse-only")
    claude_plugin = json.loads((plugin_root / ".claude-plugin/plugin.json").read_text(encoding="utf-8"))
    if claude_plugin.get("hooks") != "./hooks/claude-hooks.json":
        raise SystemExit("Claude plugin.json must point hooks at ./hooks/claude-hooks.json")
    agy_hooks = json.loads((plugin_root / "antigravity/hooks.json").read_text(encoding="utf-8"))
    if "runspecimen-block-approve" not in agy_hooks:
        raise SystemExit("antigravity/hooks.json must define runspecimen-block-approve")
    agy_pre = (agy_hooks.get("runspecimen-block-approve") or {}).get("PreToolUse")
    if not isinstance(agy_pre, list) or not agy_pre:
        raise SystemExit("antigravity/hooks.json must use Antigravity PreToolUse (not Gemini BeforeTool)")
    if "BeforeTool" in json.dumps(agy_hooks):
        raise SystemExit("antigravity/hooks.json must not include Gemini BeforeTool")
    agy_plugin = json.loads((plugin_root / "antigravity/plugin.json").read_text(encoding="utf-8"))
    if agy_plugin.get("name") != "runspecimen":
        raise SystemExit("antigravity/plugin.json name must be runspecimen")
    agy_mcp = json.loads((plugin_root / "antigravity/mcp_config.json").read_text(encoding="utf-8"))
    if "runspecimen" not in (agy_mcp.get("mcpServers") or {}):
        raise SystemExit("antigravity/mcp_config.json must declare runspecimen server")
    muse_hooks = json.loads(
        (plugin_root / "muse/examples/hooks.beta.json").read_text(encoding="utf-8")
    )
    if "PreToolUse" not in (muse_hooks.get("hooks") or {}):
        raise SystemExit("muse/examples/hooks.beta.json must define PreToolUse")
    muse_mcp = json.loads(
        (plugin_root / "muse/examples/mcp_settings.fragment.json").read_text(encoding="utf-8")
    )
    if "runspecimen" not in (muse_mcp.get("mcp_servers") or {}):
        raise SystemExit("muse MCP fragment must declare runspecimen under mcp_servers")
    gate_name = "block_approve_gate.py"
    shared_gate = (plugin_root / "scripts" / gate_name).read_bytes()
    staged_gate = (plugin_root / "antigravity" / "scripts" / gate_name).read_bytes()
    if shared_gate != staged_gate:
        raise SystemExit(
            f"antigravity/scripts/{gate_name} must match plugins/runspecimen/scripts/{gate_name}"
        )
    canonical_mcp = _load_script_module(
        plugin_root / "scripts" / "runspecimen_mcp.py", "rs_mcp_canonical_check"
    )
    staged_mcp = _load_script_module(
        plugin_root / "antigravity" / "scripts" / "runspecimen_mcp.py",
        "rs_mcp_antigravity_check",
    )
    if "approve" in canonical_mcp.ALLOWED or canonical_mcp.ALLOWED != staged_mcp.ALLOWED:
        raise SystemExit("antigravity MCP must re-export the canonical allow-list and omit approve")
    canonical_tools = [tool["name"] for tool in canonical_mcp.TOOLS]
    staged_tools = [tool["name"] for tool in staged_mcp.TOOLS]
    if canonical_tools != staged_tools or "approve" in canonical_tools:
        raise SystemExit("antigravity MCP tools diverged from the canonical server")
    plugin_xml = (
        plugin_root / "jetbrains/intellij-plugin/src/main/resources/META-INF/plugin.xml"
    ).read_text(encoding="utf-8")
    if "ApproveAction" in plugin_xml or re.search(r">\s*Approve\s*<", plugin_xml):
        raise SystemExit("IntelliJ plugin.xml must not expose an Approve action")
    for relative in PLUGIN_COMPONENTS:
        if not (plugin_root / relative).is_file():
            raise SystemExit(f"missing plugin component: {relative}")


def ensure_build_backend() -> None:
    """Require pip/setuptools/wheel visible under the same env the build uses.

    ``offline_env`` sets ``PYTHONNOUSERSITE=1``, so a user-site-only
    ``setuptools>=77`` must not pass this check — that combination produces
    ``UNKNOWN-0.0.0`` sdists when the system setuptools is too old for PEP 621.
    """
    probe = (
        "import re\n"
        "import setuptools\n"
        "import wheel  # noqa: F401\n"
        "import pip  # noqa: F401\n"
        "match = re.match(r'(\\d+)', setuptools.__version__)\n"
        "raise SystemExit(0 if match and int(match.group(1)) >= 77 else 2)\n"
    )
    result = subprocess.run(
        [sys.executable, "-c", probe],
        env=offline_env(),
        text=True,
        stdin=subprocess.DEVNULL,
        capture_output=True,
        timeout=60,
    )
    if result.returncode == 0:
        return
    if result.returncode == 2:
        raise SystemExit(
            "setuptools>=77 must be installed in this interpreter's site-packages "
            "(not only --user); offline release builds set PYTHONNOUSERSITE=1. "
            "Use a venv / .tools Python, or: python3 -m pip install --upgrade 'setuptools>=77' wheel"
        )
    detail = (result.stderr or result.stdout or "").strip()
    raise SystemExit(
        "pip, setuptools>=77, and wheel are required under PYTHONNOUSERSITE=1; "
        f"run sh scripts/bootstrap_dev.sh first ({detail})"
    )


def offline_env() -> dict[str, str]:
    env = os.environ.copy()
    for name in ("PYTHONPATH", "PYTHONHOME", "PYTHONUNBUFFERED"):
        env.pop(name, None)
    env.update({
        "PIP_CONFIG_FILE": os.devnull, "PIP_NO_INDEX": "1",
        "PIP_DISABLE_PIP_VERSION_CHECK": "1", "PIP_NO_CACHE_DIR": "1",
        "PYTHONNOUSERSITE": "1", "PYTHONDONTWRITEBYTECODE": "1",
    })
    return env


def release_build_env(env: dict[str, str]) -> dict[str, str]:
    """Pin ``SOURCE_DATE_EPOCH`` so setuptools archive timestamps ignore the clock."""
    build_env = dict(env)
    build_env["SOURCE_DATE_EPOCH"] = str(ARCHIVE_MTIME)
    return build_env


def normalized_sdist_mode(member: tarfile.TarInfo) -> int:
    """Map builder umask bits onto a two-mode reproducible set."""
    if member.isdir() or member.mode & 0o111:
        return 0o755
    return 0o644


def stage_source(destination: Path) -> None:
    destination.mkdir()
    ignore = shutil.ignore_patterns(".runspecimen", "__pycache__", "*.py[cod]", "*.egg-info", ".DS_Store")
    for name in SOURCE_COMPONENTS:
        source = ROOT / name
        if source.is_dir():
            shutil.copytree(source, destination / name, ignore=ignore, symlinks=True)
        elif source.is_file():
            shutil.copy2(source, destination / name)
    links = [str(path.relative_to(destination)) for path in destination.rglob("*") if path.is_symlink()]
    if links:
        raise SystemExit(f"release source must not contain symbolic links: {links}")


def safe_members(names: list[str]) -> None:
    if len(set(names)) != len(names):
        raise SystemExit("release archive contains duplicate members")
    for name in names:
        path = PurePosixPath(name)
        if (path.is_absolute() or ".." in path.parts or "\\" in name
                or FORBIDDEN_PARTS.intersection(path.parts)
                or path.suffix in {".pyc", ".pyo"}):
            raise SystemExit(f"unexpected or unsafe release archive member: {name}")


def inspect_sdist(path: Path, destination: Path) -> Path:
    """Validate the distribution before extracting regular files/directories."""
    with tarfile.open(path, "r:gz") as archive:
        members = archive.getmembers()
        safe_members([member.name for member in members])
        top = f"runspecimen-{EXPECTED_PYTHON_VERSION}"
        names = {member.name for member in members}
        required = {f"{top}/{relative}" for relative in (
            "pyproject.toml", "LICENSE", "README.md", "src/runspecimen/cli.py",
            "src/runspecimen/dashboard.py", "src/runspecimen/py.typed",
            "scripts/release_check.py", "tests/test_demo_cli.py", "work/compute.py",
            "examples/demo_contract.json",
            "packaging/homebrew/runspecimen.rb",
            "examples/templates/research/contract.json",
            "examples/templates/security/contract.json",
            "examples/templates/shared-policy/policy.json",
            "examples/templates/ml-eval/contract.json",
            "examples/campaigns/adversarial-first-run/contract.json",
            *(f"plugins/runspecimen/{name}" for name in PLUGIN_COMPONENTS),
        )}
        if not required.issubset(names):
            raise SystemExit(f"source archive is missing required files: {sorted(required - names)}")
        carried = [name for name in names if _is_platform_verifier_member(name)]
        if carried:
            raise SystemExit(
                "source archive must not carry the darwin arm64 verifier: " + ", ".join(carried)
            )
        for member in members:
            if PurePosixPath(member.name).parts[0] != top or not (member.isfile() or member.isdir()):
                raise SystemExit(f"unsupported source archive member: {member.name}")
            target = destination / member.name
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                source = archive.extractfile(member)
                if source is None:
                    raise SystemExit(f"unreadable source archive member: {member.name}")
                with source, target.open("wb") as output:
                    shutil.copyfileobj(source, output)
    return destination / top


# Optional extras may appear as Requires-Dist with an ``extra == "…"`` marker.
# Hard (unconditional) dependencies remain forbidden so default installs stay
# stdlib-only. Keep this list in sync with ``[project.optional-dependencies]``.
VETTED_OPTIONAL_EXTRAS = frozenset({"ed25519", "signing"})
_VETTED_OPTIONAL_REQUIREMENT_NAMES = frozenset({"pynacl"})
_REQUIRES_DIST_RE = re.compile(r"^Requires-Dist:\s*(.+)$", re.MULTILINE)
_EXTRA_MARKER_RE = re.compile(
    r"""extra\s*==\s*(?P<q>['"])(?P<extra>[A-Za-z0-9._-]+)(?P=q)"""
)
_REQUIREMENT_NAME_RE = re.compile(r"^\s*([A-Za-z0-9][A-Za-z0-9._-]*)")


def validate_requires_dist_metadata(metadata: str) -> None:
    """Ensure METADATA declares no hard deps; only vetted optional extras.

    Raises SystemExit with a clear message on policy violations.
    """
    for raw in _REQUIRES_DIST_RE.findall(metadata):
        line = raw.strip()
        if ";" not in line:
            raise SystemExit(
                "the dependency-free runtime unexpectedly declares a hard dependency: "
                f"Requires-Dist: {line}"
            )
        requirement, marker = line.split(";", 1)
        name_match = _REQUIREMENT_NAME_RE.match(requirement)
        if name_match is None:
            raise SystemExit(f"unparseable Requires-Dist requirement: {line}")
        req_name = name_match.group(1).lower().replace("_", "-")
        extras = {match.group("extra") for match in _EXTRA_MARKER_RE.finditer(marker)}
        if not extras:
            raise SystemExit(
                "Requires-Dist marker must bind to an optional extra "
                f"(got: Requires-Dist: {line})"
            )
        unknown = extras - VETTED_OPTIONAL_EXTRAS
        if unknown:
            raise SystemExit(
                f"unvetted optional extra(s) in Requires-Dist: {sorted(unknown)} "
                f"(allowed: {sorted(VETTED_OPTIONAL_EXTRAS)})"
            )
        if req_name not in _VETTED_OPTIONAL_REQUIREMENT_NAMES:
            raise SystemExit(
                f"unvetted optional dependency {req_name!r} for extras {sorted(extras)} "
                f"(allowed packages: {sorted(_VETTED_OPTIONAL_REQUIREMENT_NAMES)})"
            )


def _is_platform_verifier_member(name: str) -> bool:
    return name.endswith("runspecimen/platform/darwin_arm64/native_p256_verify") or (
        name.rsplit("/", 1)[-1] == "native_p256_verify"
    )


def inspect_wheel(path: Path) -> None:
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        safe_members(names)
        dist_info = f"runspecimen-{EXPECTED_PYTHON_VERSION}.dist-info"
        required = {
            "runspecimen/cli.py", "runspecimen/dashboard.py", "runspecimen/py.typed",
            f"{dist_info}/METADATA", f"{dist_info}/RECORD",
            f"{dist_info}/entry_points.txt",
            # Note: licenses/LICENSE may or may not be present depending on setuptools version
        }
        if not required.issubset(names):
            raise SystemExit(f"wheel is missing required files: {sorted(required - set(names))}")
        if path.name.endswith("py3-none-any.whl"):
            carried = [name for name in names if _is_platform_verifier_member(name)]
            if carried:
                raise SystemExit(
                    "py3-none-any wheel must not carry the darwin arm64 verifier: "
                    + ", ".join(carried)
                )
        metadata = archive.read(f"{dist_info}/METADATA").decode("utf-8")
        if f"\nVersion: {EXPECTED_PYTHON_VERSION}\n" not in metadata:
            raise SystemExit("wheel metadata has the wrong version")
        validate_requires_dist_metadata(metadata)


def build_plugin(source: Path, output: Path) -> None:
    plugin = source / "plugins/runspecimen"
    files = sorted(path for path in plugin.rglob("*") if path.is_file())
    entries = [(f"runspecimen/{path.relative_to(plugin).as_posix()}", path) for path in files]
    entries.append(("runspecimen/LICENSE", source / "LICENSE"))
    safe_members([name for name, _ in entries])
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, path in entries:
            info = zipfile.ZipInfo(name, date_time=ARCHIVE_ZIP_DATE)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())


def smoke_dashboard(python: Path, workspace: Path, contract: Path, env: dict[str, str]) -> None:
    """Exercise the installed wheel's loopback server in one process.

    macOS hosted runners do not reliably permit a parent process to probe a
    separately spawned loopback server, despite allowing the server itself.
    """
    script = """
import json, threading, urllib.error, urllib.request
from pathlib import Path
from runspecimen.dashboard import start_dashboard
workspace, contract = map(Path, __import__('sys').argv[1:3])
server, url = start_dashboard(workspace=workspace, contract_path=contract)
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
try:
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(url, timeout=5) as response:
        page = response.read().decode('utf-8')
        assert 'RunSpecimen' in page and response.headers.get('Cache-Control') == 'no-store'
    with opener.open(url + 'api/status', timeout=5) as response:
        status = json.load(response)
        assert status.get('campaign_id') == 'release-smoke' and status.get('approval') is None
    try:
        opener.open(urllib.request.Request(url + 'api/status', data=b'{}', method='POST'), timeout=5)
    except urllib.error.HTTPError as exc:
        assert exc.code == 405
    else:
        raise AssertionError('dashboard accepted a mutation')
finally:
    server.shutdown(); thread.join(timeout=5); server.server_close()
"""
    run(str(python), "-c", script, str(workspace), str(contract), cwd=workspace, env=env)


def _run_checked(cli: Path, *args: str, cwd: Path, env: dict[str, str],
                  expect_failure: bool = False) -> subprocess.CompletedProcess[str]:
    """Run CLI command and return result, optionally expecting failure."""
    cmd = [str(cli)] + list(args)
    print("+", " ".join(cmd), flush=True)
    result = subprocess.run(
        cmd, cwd=cwd, env=env, text=True, timeout=60,
        stdin=subprocess.DEVNULL, capture_output=True,
    )
    if expect_failure and result.returncode == 0:
        raise SystemExit(f"expected failure but command succeeded: {' '.join(cmd)}")
    if not expect_failure and result.returncode != 0:
        raise SystemExit(f"command failed: {' '.join(cmd)}\nstderr: {result.stderr}")
    return result


def smoke_signing(cli: Path, python: Path, workspace: Path, contract: Path, env: dict[str, str]) -> None:
    """Exercise sign, verify-signature, keygen, and list-keys with real command entry.

    Tests keygen/list-keys success paths and sign/verify-signature error paths.
    Does not approve or execute any payload; validates that commands enter their
    logic branches and produce clean errors (no tracebacks) for controlled invalid inputs.
    """
    # --- keygen success ---
    result = _run_checked(cli, "keygen", "--workspace", str(workspace), "--key-id", "smoke-key",
                          cwd=workspace, env=env)
    keygen_output = json.loads(result.stdout)
    if not keygen_output.get("ok"):
        raise SystemExit(f"keygen failed: {result.stderr}")

    # --- list-keys success ---
    result = _run_checked(cli, "list-keys", "--workspace", str(workspace),
                          cwd=workspace, env=env)
    list_output = json.loads(result.stdout)
    if "smoke-key" not in list_output.get("key_ids", []):
        raise SystemExit(f"list-keys did not show created key: {result.stdout}")

    # --- sign: missing certificate file (enters command branch, expects clean error) ---
    missing_cert = workspace / "nonexistent-certificate.json"
    result = _run_checked(
        cli, "sign",
        "--workspace", str(workspace),
        "--key-id", "smoke-key",
        "--certificate", str(missing_cert),
        "--contract", str(contract),
        cwd=workspace, env=env, expect_failure=True,
    )
    if "Traceback" in result.stderr:
        raise SystemExit(f"sign with missing certificate produced traceback:\n{result.stderr}")
    if "error" not in result.stderr.lower() and "not found" not in result.stderr.lower():
        raise SystemExit(f"sign with missing certificate did not report error: {result.stderr}")

    # --- sign: invalid JSON certificate (enters command branch, expects clean error) ---
    invalid_cert = workspace / "invalid-certificate.json"
    invalid_cert.write_text("this is not valid json {{{{", encoding="utf-8")
    result = _run_checked(
        cli, "sign",
        "--workspace", str(workspace),
        "--key-id", "smoke-key",
        "--certificate", str(invalid_cert),
        "--contract", str(contract),
        cwd=workspace, env=env, expect_failure=True,
    )
    if "Traceback" in result.stderr:
        raise SystemExit(f"sign with invalid JSON produced traceback:\n{result.stderr}")

    # --- sign: missing key (enters command branch, expects clean error) ---
    # Create a minimal but valid JSON certificate to pass JSON parsing
    minimal_cert = workspace / "minimal-certificate.json"
    minimal_cert.write_text('{"campaign_id": "test", "run_id": "test"}', encoding="utf-8")
    result = _run_checked(
        cli, "sign",
        "--workspace", str(workspace),
        "--key-id", "nonexistent-key",
        "--certificate", str(minimal_cert),
        "--contract", str(contract),
        cwd=workspace, env=env, expect_failure=True,
    )
    if "Traceback" in result.stderr:
        raise SystemExit(f"sign with missing key produced traceback:\n{result.stderr}")
    if "error" not in result.stderr.lower():
        raise SystemExit(f"sign with missing key did not report error: {result.stderr}")

    # --- verify-signature: missing signed file (enters command branch, expects clean error) ---
    # Note: verify-signature outputs JSON to stdout even on failure
    missing_signed = workspace / "nonexistent.signed.json"
    result = _run_checked(
        cli, "verify-signature",
        "--workspace", str(workspace),
        "--key-id", "smoke-key",
        "--signed", str(missing_signed),
        "--contract", str(contract),
        cwd=workspace, env=env, expect_failure=True,
    )
    if "Traceback" in result.stderr or "Traceback" in result.stdout:
        raise SystemExit(f"verify-signature with missing file produced traceback:\n{result.stderr}\n{result.stdout}")
    combined = result.stderr.lower() + result.stdout.lower()
    if "error" not in combined and "not found" not in combined:
        raise SystemExit(f"verify-signature with missing file did not report error: stdout={result.stdout}, stderr={result.stderr}")

    # --- verify-signature: invalid JSON (enters command branch, expects clean error) ---
    invalid_signed = workspace / "invalid.signed.json"
    invalid_signed.write_text("not valid json }}}}", encoding="utf-8")
    result = _run_checked(
        cli, "verify-signature",
        "--workspace", str(workspace),
        "--key-id", "smoke-key",
        "--signed", str(invalid_signed),
        "--contract", str(contract),
        cwd=workspace, env=env, expect_failure=True,
    )
    if "Traceback" in result.stderr or "Traceback" in result.stdout:
        raise SystemExit(f"verify-signature with invalid JSON produced traceback:\n{result.stderr}\n{result.stdout}")

    # --- verify-signature: missing key (enters command branch, expects clean error) ---
    # Create a minimal signed structure
    minimal_signed = workspace / "minimal.signed.json"
    minimal_signed.write_text('{"certificate": {}, "signature": "abc", "key_id": "test"}', encoding="utf-8")
    result = _run_checked(
        cli, "verify-signature",
        "--workspace", str(workspace),
        "--key-id", "nonexistent-key",
        "--signed", str(minimal_signed),
        "--contract", str(contract),
        cwd=workspace, env=env, expect_failure=True,
    )
    if "Traceback" in result.stderr or "Traceback" in result.stdout:
        raise SystemExit(f"verify-signature with missing key produced traceback:\n{result.stderr}\n{result.stdout}")
    combined = result.stderr.lower() + result.stdout.lower()
    if "error" not in combined and "not found" not in combined:
        raise SystemExit(f"verify-signature with missing key did not report error: stdout={result.stdout}, stderr={result.stderr}")


def assert_installed_wheel_identity(
    python: Path, wheel: Path, env: dict[str, str]
) -> None:
    """Require the installed package to come from the wheel, not an in-tree src/.

    ``tests/helpers.py`` prepends the repository ``src`` directory to
    ``sys.path``. This check uses a clean interpreter with empty
    ``PYTHONPATH`` and compares installed files to the wheel RECORD.
    """
    if env.get("PYTHONPATH"):
        raise SystemExit(
            "installed-wheel identity check requires an empty PYTHONPATH, "
            f"got {env.get('PYTHONPATH')!r}"
        )
    probe = r"""
import base64
import hashlib
import os
import pathlib
import sys
import zipfile

wheel = pathlib.Path(sys.argv[1])
if os.environ.get("PYTHONPATH"):
    raise SystemExit(f"PYTHONPATH is set: {os.environ.get('PYTHONPATH')!r}")
import runspecimen

package_file = pathlib.Path(runspecimen.__file__).resolve()
parts = set(package_file.parts)
if "site-packages" not in parts and "dist-packages" not in parts:
    raise SystemExit(
        "runspecimen.__file__ is not under site-packages: " + str(package_file)
    )
site_root = package_file.parent.parent
with zipfile.ZipFile(wheel) as archive:
    record_names = [name for name in archive.namelist() if name.endswith(".dist-info/RECORD")]
    if len(record_names) != 1:
        raise SystemExit(f"expected one RECORD member, got {record_names}")
    rows = []
    for line in archive.read(record_names[0]).decode("utf-8").splitlines():
        if not line:
            continue
        name, sep, rest = line.partition(",")
        if not sep:
            raise SystemExit(f"malformed RECORD line: {line!r}")
        digest, size_sep, size = rest.partition(",")
        if not size_sep:
            raise SystemExit(f"malformed RECORD line: {line!r}")
        rows.append((name, digest, size))
missing = []
mismatched = []
for name, digest, size in rows:
    if name.endswith("/"):
        continue
    installed = site_root / name
    if name.endswith(".dist-info/RECORD"):
        if digest != "":
            raise SystemExit(f"RECORD hashed itself: {digest}")
        if not installed.is_file():
            missing.append(name)
        continue
    if not installed.is_file():
        missing.append(name)
        continue
    data = installed.read_bytes()
    if size and size != str(len(data)):
        mismatched.append(f"{name} size {len(data)} != {size}")
        continue
    if digest:
        encoded = base64.urlsafe_b64encode(hashlib.sha256(data).digest()).decode("ascii").rstrip("=")
        expected = f"sha256={encoded}"
        if digest != expected:
            mismatched.append(f"{name} hash {digest} != {expected}")
if missing or mismatched:
    raise SystemExit(
        "installed files do not match the wheel RECORD: "
        + "; ".join(missing + mismatched)
    )
print(str(package_file))
"""
    result = run(
        str(python),
        "-c",
        probe,
        str(wheel),
        env=env,
        capture=True,
    )
    installed = result.stdout.strip()
    if "site-packages" not in installed and "dist-packages" not in installed:
        raise SystemExit(f"installed identity probe did not report site-packages: {installed}")


def trusted_base_executable() -> str:
    """Base interpreter for venv creation, install, and the static check.

    The process that built the archives may be a tools virtual environment.
    That environment is not the interpreter the check accepts.
    """
    spec = importlib.util.spec_from_file_location(
        "verify_installed_wheel_base",
        ROOT / "scripts" / "verify_installed_wheel.py",
    )
    if spec is None or spec.loader is None:
        raise SystemExit("cannot load verify_installed_wheel.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    found = module.base_interpreter()
    if found is None:
        raise SystemExit(
            "release smoke must start the wheel check with the base interpreter; "
            f"{sys.executable} is a virtual environment and its base was not found"
        )
    return str(found)


def smoke_install(wheel: Path, source: Path, temp: Path, env: dict[str, str]) -> None:
    base = trusted_base_executable()
    venv = temp / "venv"
    run(base, "-I", "-S", "-m", "venv", "--without-pip", str(venv), cwd=temp, env=env)
    digest = hashlib.sha256(wheel.read_bytes()).hexdigest()
    installer = ROOT / "scripts" / "install_pinned_wheel.py"
    verifier = ROOT / "scripts" / "verify_installed_wheel.py"
    run(
        base, "-I", "-S", str(installer),
        "--wheel", str(wheel),
        "--venv", str(venv),
        "--expected-sha256", digest,
        cwd=temp,
        env=env,
    )
    python = venv / "bin/python"
    cli = venv / "bin/runspecimen"
    run(
        base, "-I", "-S", str(verifier),
        "--wheel", str(wheel),
        "--launcher", str(cli),
        cwd=temp,
        env=env,
    )
    smoke_env = dict(env, PATH=str(venv / "bin") + os.pathsep + env.get("PATH", ""))
    if smoke_env.get("PYTHONPATH"):
        raise SystemExit("release smoke must run with an empty PYTHONPATH")
    assert_installed_wheel_identity(python, wheel, smoke_env)
    version = run(str(cli), "--version", cwd=temp, env=smoke_env, capture=True).stdout.strip()
    if version != f"runspecimen {EXPECTED_PYTHON_VERSION}":
        raise SystemExit(f"installed console script has an unexpected version: {version}")
    run(str(python), "-m", "runspecimen", "--version", cwd=temp, env=smoke_env)
    workspace = temp / "smoke-workspace"
    (workspace / "work").mkdir(parents=True)
    shutil.copy2(source / "work/compute.py", workspace / "work/compute.py")
    contract = workspace / "contract.json"
    doc = json.loads((source / "examples/demo_contract.json").read_text(encoding="utf-8"))
    doc.update(campaign_id="release-smoke", run_id="unapproved", argv=[str(python), "work/compute.py"])
    contract.write_text(json.dumps(doc), encoding="utf-8")
    for action in ("doctor", "validate", "status"):
        args = [str(cli), action, "--workspace", str(workspace)]
        if action != "doctor":
            args.extend(["--contract", str(contract)])
        if action == "status":
            args.extend(["--campaign-id", "release-smoke", "--run-id", "unapproved"])
        result = json.loads(run(*args, cwd=workspace, env=smoke_env, capture=True).stdout)
        if action != "status" and result.get("ok") is not True:
            raise SystemExit(f"installed {action} check failed")
    run(str(python), str(source / "plugins/runspecimen/scripts/runspecimen_adapter.py"),
        "doctor", "--workspace", str(workspace), cwd=workspace, env=smoke_env)
    run(str(cli), "dashboard", "--help", cwd=workspace, env=smoke_env, capture=True)
    smoke_dashboard(python, workspace, contract, smoke_env)
    smoke_signing(cli, python, workspace, contract, smoke_env)
    if list(workspace.rglob("approval.json")) or (workspace / "outputs").exists():
        raise SystemExit("read-only release smoke unexpectedly approved or executed its payload")


def normalize_sdist_timestamps(path: Path, mtime: int = ARCHIVE_MTIME) -> None:
    """Rewrite the sdist so archive metadata does not depend on the builder.

    setuptools honors ``SOURCE_DATE_EPOCH`` for some timestamps but still
    records the builder uid/gid/uname and the local walk order. Those fields
    change the archive bytes across hosts even when file contents match
    (OPEN-SDIST: committed ``b2db7b78…`` vs a non-ubuntu rebuild ``6979460d…``).
    This rewrite keeps names and file bytes, then pins:

    * tar member mtime to ``SOURCE_DATE_EPOCH`` / ``ARCHIVE_MTIME``
    * uid/gid 0 and empty uname/gname (numeric-owner zero record)
    * modes 0755 for directories and executables, 0644 otherwise
    * members sorted by name
    * gzip header mtime 0 and no original filename
    * USTAR (not PAX) so Python versions do not emit extra pax headers
    """
    with tarfile.open(path, "r:gz") as inbound:
        records: list[tuple[tarfile.TarInfo, bytes | None]] = []
        for member in inbound.getmembers():
            if member.isdir():
                records.append((member, None))
            elif member.isfile():
                extracted = inbound.extractfile(member)
                if extracted is None:
                    raise SystemExit(f"unreadable source archive member: {member.name}")
                records.append((member, extracted.read()))
            else:
                raise SystemExit(f"unsupported source archive member: {member.name}")

    records.sort(key=lambda item: item[0].name)
    expected_names = [member.name for member, _payload in records]

    buffer = io.BytesIO()
    with gzip.GzipFile(
        filename="", mode="wb", fileobj=buffer, mtime=GZIP_MTIME, compresslevel=9,
    ) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.USTAR_FORMAT) as outbound:
            for member, payload in records:
                info = tarfile.TarInfo(member.name)
                info.mtime = mtime
                info.mode = normalized_sdist_mode(member)
                info.uid = 0
                info.gid = 0
                info.uname = ""
                info.gname = ""
                if payload is None:
                    info.type = tarfile.DIRTYPE
                    outbound.addfile(info)
                else:
                    info.type = tarfile.REGTYPE
                    info.size = len(payload)
                    outbound.addfile(info, io.BytesIO(payload))
    rewritten = buffer.getvalue()
    with tarfile.open(fileobj=io.BytesIO(rewritten), mode="r:gz") as check:
        checked = check.getmembers()
        if [member.name for member in checked] != expected_names:
            raise SystemExit("rewritten source archive changed member names")
        for current, (_member, payload) in zip(checked, records):
            if current.mtime != mtime:
                raise SystemExit(f"source archive member kept a moving timestamp: {current.name}")
            if current.uid != 0 or current.gid != 0 or current.uname or current.gname:
                raise SystemExit(f"source archive member kept builder identity: {current.name}")
            if payload is None:
                if not current.isdir():
                    raise SystemExit(f"rewritten source archive changed a directory: {current.name}")
                continue
            extracted = check.extractfile(current)
            if extracted is None or extracted.read() != payload:
                raise SystemExit(f"rewritten source archive changed file contents: {current.name}")
    path.write_bytes(rewritten)


def build_release_archives(temp: Path, env: dict[str, str]) -> tuple[Path, Path, Path]:
    """Stage sources in *temp* and build a timestamp-stable sdist and wheel.

    Returns ``(sdist, wheel, extracted_source)``. Does not run the unit suite
    or the install smoke test. The plugin zip is built by the caller.
    """
    artifacts = temp / "artifacts"
    artifacts.mkdir()
    source = temp / "source"
    stage_source(source)
    run(sys.executable, "-m", "compileall", "-q", "src", "scripts", cwd=source, env=env)
    build_env = release_build_env(env)
    run(
        sys.executable, "-c",
        "from setuptools.build_meta import build_sdist; build_sdist(" + repr(str(artifacts)) + ")",
        cwd=source, env=build_env,
    )
    sdists = list(artifacts.glob("runspecimen-*.tar.gz"))
    if len(sdists) != 1:
        raise SystemExit(f"expected one source archive, got {sdists}")
    normalize_sdist_timestamps(sdists[0])
    extracted = inspect_sdist(sdists[0], temp / "extracted")
    run(
        sys.executable, "-m", "pip", "wheel", "--no-index", "--no-deps", "--no-build-isolation",
        "--wheel-dir", str(artifacts), str(extracted), cwd=temp, env=build_env,
    )
    wheels = list(artifacts.glob("runspecimen-*.whl"))
    if len(wheels) != 1:
        raise SystemExit(f"expected one wheel, got {wheels}")
    inspect_wheel(wheels[0])
    return sdists[0], wheels[0], extracted


def retain_artifacts(artifacts: Path, destination: Path) -> None:
    """Never replace a prior release, even when it has the same version."""
    if destination.exists() and (not destination.is_dir() or any(destination.iterdir())):
        raise SystemExit(f"output directory must be absent or empty: {destination}")
    destination.mkdir(parents=True, exist_ok=True)
    for path in sorted(artifacts.iterdir()):
        with path.open("rb") as source, (destination / path.name).open("xb") as output:
            shutil.copyfileobj(source, output)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, help="retain validated artifacts in an absent or empty directory")
    args = parser.parse_args(argv)
    if args.output_dir is not None:
        args.output_dir = args.output_dir.resolve()
        if args.output_dir.exists() and (not args.output_dir.is_dir() or any(args.output_dir.iterdir())):
            parser.error(f"output directory must be absent or empty: {args.output_dir}")
    check_versions()
    ensure_build_backend()
    env = offline_env()
    # Darwin 3.11 with the holder-stage test can pass 600s while still copying
    # files. Push run 38279619647 timed out there; pull request run 38279624560
    # finished. 900s is the cap for that progress, not a claim that both runs
    # were green.
    run(
        sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v",
        env=env, timeout=900,
    )
    with tempfile.TemporaryDirectory(prefix="runspecimen-release-") as directory:
        temp = Path(directory)
        sdist, wheel, extracted = build_release_archives(temp, env)
        # DistributionArtifactTests must pass against the *extracted* sdist tree,
        # not only the git checkout (catches MANIFEST.in omissions).
        run(
            sys.executable, "-m", "unittest",
            "tests.test_phases.DistributionArtifactTests",
            "-v",
            cwd=extracted,
            env=env,
        )
        artifacts = sdist.parent
        smoke_install(wheel, extracted, temp, env)
        build_plugin(extracted, artifacts / f"runspecimen-plugin-{EXPECTED_PLUGIN_VERSION}.zip")
        report = {
            "ok": True, "version": EXPECTED_PYTHON_VERSION, "plugin_version": EXPECTED_PLUGIN_VERSION,
            "python": sys.version.split()[0], "platform": sys.platform,
            "checks": ["unit-tests", "source-compile", "source-archive-contents",
                       "sdist-distribution-artifact-tests", "wheel-from-source-archive",
                       "wheel-contents", "fresh-install-console-script",
                       "installed-wheel-site-packages-record",
                       "installed-cli-doctor-validate-status",
                       "installed-plugin-adapter", "installed-dashboard-http", "dashboard-write-refusal",
                       "installed-keygen-listkeys", "installed-sign-verify-error-handling"],
            "artifacts": {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                          for path in sorted(artifacts.iterdir())},
        }
        (artifacts / "release-report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        hashes = [f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.name}\n" for path in sorted(artifacts.iterdir())]
        (artifacts / "SHA256SUMS").write_text("".join(hashes), encoding="utf-8")
        if args.output_dir is not None:
            retain_artifacts(artifacts, args.output_dir)
            print(f"Validated release artifacts: {args.output_dir}")
    print("RunSpecimen release candidate checks passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
