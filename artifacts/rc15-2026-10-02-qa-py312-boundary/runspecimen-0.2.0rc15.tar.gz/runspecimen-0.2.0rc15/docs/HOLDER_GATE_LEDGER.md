# Holder gate ledger

This ledger separates engineering that is in the tree from actions a person still has to perform. The bridge implementation is engineering. It is not a wait on Yahor. This note is not a production sign-off and it is not Store parity. Approved Mac App Store **0.1.4 (9)** is a different package. The Store app stays guarantee (1), a typed phrase. The Developer ID holder is guarantee (2). The Store app does not have guarantee (2).

## Engineering in this tree

| Gate | What the code does |
| --- | --- |
| Verifier placement | The Darwin arm64 `native_p256_verify` binary is loaded from `runspecimen/platform/darwin_arm64/`. The `py3-none-any` wheel does not carry that Mach-O. Other platforms fail closed. |
| Verifier identity | A signature is accepted only when the binary's `TeamIdentifier` and designated requirement match a pin, and `codesign --verify --strict` succeeds. A display name that contains "Developer ID" is not that pin. `production_verifier_pin()` is unset, so the packaged ad-hoc binary is not a production publisher. |
| Isolated double | `isolated-native-bridge-double-not-hardware` enrolls, pairs, and signs for local, companion, and dual when the test pin matches and installed protection is off. Those runs stay `hardware: false`. Installed protection refuses the double. |
| Production boundary | `native-production-bridge` with `production-boundary-double-not-hardware` enrolls, pairs, and signs for local, companion, and dual when a pin is injected and the verifier team and designated requirement match. The record stays `hardware: false`. An unset pin, a hardware claim, a wrong team, a wrong requirement, or a Developer ID display string fails closed. `production_verifier_pin()` stays unset. |
| Labeled test double | `labeled-native-bridge-double-not-hardware` remains a separate unprivileged double. It is not the isolated path and it is not installed protection. |
| Production hardware | `allowsProductionEnrollment` is false for Secure Enclave key creation. It is true only for the boundary path when a pin and a verifier are injected. This tree does not call `SecureEnclave.P256.Signing.PrivateKey` and does not prompt. Source integration and trust configuration remain open. |
| Mac app control | `IsolatedNativeEnrollment.complete` records a local or companion engineering signer. `ProductionNativeBridgeGate` reports those signers and keeps hardware enrollment closed. |

The production team identifier and designated requirement string are not in this protocol. The code fails closed until that pin exists. That is one unresolved design choice, not a reason to leave the engineering path as an unconditional refusal.

## Human acceptance steps, not run by this agent

1. Biometric enrollment. On the signed holder, create the Mac key with `SecureEnclave.P256.Signing.PrivateKey`. That raises Touch ID, Face ID, or a password prompt.
2. Fingerprint confirmation. Compare the Mac public-key fingerprint, then the paired phone's fingerprint, before the holder stores either key.
3. Privileged install. Install the holder only through the privileged path. The live `/Applications/RunSpecimen Holder.app` is not repaired from this ledger.
4. One real bounded run after those enrollments. Do not type APPROVE and do not pass `--human-invoked` from automation.

## Packaging

The pure wheel stays `py3-none-any` and must not contain `native_p256_verify`. The holder loads the helper from `platform/darwin_arm64/` in the runtime tree. A hash file next to an ad-hoc signature does not establish a trusted publisher. Trust is the pinned team identifier plus the designated requirement.
