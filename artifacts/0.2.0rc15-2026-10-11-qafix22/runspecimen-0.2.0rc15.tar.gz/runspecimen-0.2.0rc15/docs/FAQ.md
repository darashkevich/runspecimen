# RunSpecimen FAQ

Short answers grounded in the current CLI and product constraints. Product
overview: [ABOUT.md](ABOUT.md). Deeper how-to: [USER_GUIDE.md](USER_GUIDE.md).

## How is this different from ChatGPT / an agent chat?

Chat answers and tool suggestions are not an execution gate. RunSpecimen sits
**beside** the agent: a human TTY approval binds the contract, source tree, and
resolved executable; a workspace lease allows only one mutating lifecycle step
at a time; postflight and verify produce a local receipt. The agent may draft
contracts and run preflight/run/postflight/verify after you approve—it must not
type `APPROVE` for you.

## How is this different from CI?

CI usually runs many jobs, often without interactive human binding of exact
local source + binary hashes, and is oriented to remote pipelines. RunSpecimen
is **local**, **one run at a time** per workspace lease, with mandatory
interactive approval expiry and predecessor gating before the next campaign
step. It does not replace CI; you can still verify receipts in CI if you ship
the workspace evidence with matching host runtime expectations.

## Which build is public, in review, or only on this branch?

Published CLI and plugin: **0.2.0rc14**. That release does not include evidence-expansion commands (ADR-005). This branch's engine is unpublished **0.2.0rc15** and is not the PyPI or GitHub cut.

The Mac App Store package recorded in Connect on 2026-09-28 as **0.1.4 (9)** `READY_FOR_SALE` freezes **0.2.0rc14**. That record is not a public `apps.apple.com` URL, and it is not this unpublished candidate.

## Does the Mac App Store app include the protected holder?

No. Those are different guarantees and different products.

Guarantee (1) is the Store app: a person types `APPROVE` on a real terminal for an ordinary contract. Approved **0.1.4 (9)** is that app. It does not ship the Developer ID holder.

Guarantee (2) is a separate Developer ID holder for enrollment, policy, spent nonces, and leases. It is not installed, not notarized, and not part of the Store app. HMAC, a software Ed25519 signature, a CryptoKit P-256 check, and an imported Secure Enclave label are not Touch ID, Face ID, or a hardware verifier. The P-256 helper is loaded from `platform/darwin_arm64` as described in [HOLDER_NATIVE_BRIDGE.md](HOLDER_NATIVE_BRIDGE.md) and is not inside the pure wheel. An isolated double can enroll local and companion signers for engineering tests. Installed protection refuses that double. A caller `boundary_double` flag cannot select a software key, even when a verifier pin matches. The pin checks verifier code only. It does not authorize a software key or a human biometric. The Secure Enclave prompt is the human step and is not invoked by this tree. `HumanNativeSigner` is a software signer, and installed protection still refuses it. `HumanOperatedNativeAdapter` is a software injection point. A persisted origin string is not production trust, even when the Developer ID pin matches. E2 is not closed. A biometric press does not finish missing implementation. The local control can keep a session key and enroll it. Companion and dual compare a phone peer key. The local button issues a bound challenge over the authenticated holder socket, signs it with the session key, and submits that signature. The client checks the holder response MAC, protocol, and caller id, and it binds the reply to the request. Sign with session key calls issue-exact-run, authorize-exact-run, and execute-exact-run. It reaches snapshot-bound consume and execute only when the signature matches the policy, generation, key generation, and expiry. run_integration_complete stays false. Local excludes the phone key, companion requires it, and dual requires both. That path writes the real spent record and uncertain lease, then execute recovers the lease. It is not completed run integration. A second consume of that nonce fails. Installed protection stays fail-closed until a Secure Enclave key can be identified by evidence other than an origin string or a pin match. A press or an install cannot finish that gap. The sealed session file in Application Support is not the Keychain. The paired-phone button publishes the same challenge to RunSpecimenObserve. The Observe screen calls fetchPhonePeerChallenge and submitPhonePeerSignature. Cancel during a delayed fetch does not sign and does not POST. The holder accepts the signature only after P-256 verification of the holder id, generation, role, expiry, and nonce, then consumes the challenge. A nonempty string is not a signature. The phone commits its key only after it verifies a holder receipt signed by the pinned Mac session key. A caller verified flag is not a receipt. This candidate's holder is not installed and is not notarized. An earlier app under `/Applications` is not this SHA. Installed Secure Enclave admission stays fail-closed (D1, 2026-10-05). E2 remains an engineering gap. A press or an install does not close it. Human testing cannot close missing implementation. Yahor confirmed the Developer ID holder pin in `production_verifier_pin()`. The Store app does not carry that pin and stays guarantee (1). Source integration of native enrollment remains open. A person running a biometric does not by itself finish that integration. This candidate does not claim Store parity or production sign-off. The pure wheel does not contain the Darwin verifier. `doctor` still runs and reports the verifier absent; it does not enroll. The plugin does not ship the verifier and does not pass a holder.

Prepare exact run issues one snapshot challenge and, for companion or dual, publishes that same bound value. Continue exact run checks expiry, generation, and policy, then authorizes and executes that nonce. Continue does not issue another nonce. A restarted session reloads the committed custody record and signs only when its public key matches the enrolled Mac key. The phone commits a holder receipt only after cancellation and generation still match that challenge, and a failed commit can be retried. A revoked Mac key, a revoked phone key, or a fingerprint that no longer matches the current phone record refuses the receipt, and policy, rotation, and revocation drop a pending receipt.

Installed Secure Enclave admission stays fail-closed. A holder-signed receipt of a caller-supplied key is not proof the holder created that key. Apple's current guidance says a root launchd daemon cannot use the Secure Enclave or the data protection keychain, so that daemon cannot attest creation. D1 remains the verifier pin only. A Mac-session signature proves possession of the pinned key. `run_integration_complete` stays false. See [SECURE_ENCLAVE_ADMISSION.md](SECURE_ENCLAVE_ADMISSION.md).

A local package that reused the label 0.1.4 (9) and included evidence expansion is a different file. Local **0.1.5 (10)**, **0.1.5 (11)** from `3a0f483` (SHA-256 `2452956fe1179a7e4e019f5de5b2c40aba460ecbc077a7d75af35458b67ce309`), and **0.1.5 (12)** from `c400f2d` (SHA-256 `6b3e9b3e1db219aafd834dd894b4ce04a8269cedb34dc116a4a154c22bb09a38`) are earlier packages. This branch's local successor label is **0.1.5 (13)**. That label is not an upload and not an approval. See [RELEASE_IDENTITY.md](RELEASE_IDENTITY.md) and [NATIVE_FEATURE_COVERAGE.md](NATIVE_FEATURE_COVERAGE.md).

## How is this different from a sandbox?

A sandbox limits what a process can reach. RunSpecimen records whether an
approved, exclusive, bounded step happened and whether declared outcomes
passed. It is **not** an OS sandbox.

The default `isolation.backend` is `none`: wall clock, capture size,
path-inside-workspace checks, and process-group kill. No filesystem or network
confinement.

Opt-in `sandbox-exec` (macOS, if `sandbox-exec` is on PATH) and `bwrap` (Linux,
if `bwrap` is on PATH) confine writes to the workspace and deny network unless
the contract sets `isolation.network` to true. A declared backend that is not
installed fails closed. The receipt field `isolation.residual` states what
that profile still allows, including host reads. CPU and memory limits are
not part of either backend.

## Why does approval require a TTY?

Unattended or piped approval would let an agent or script bind a consequential
command without a human at the keyboard. `approve` requires interactive stdin
**and** stdout TTYs and the exact phrase `APPROVE`. Test-only hooks
(`skip_tty_check`) exist for regenerating demos; they are not the production
path.

## How do I get human-readable CLI output?

JSON is the default for every command (agents, tests, and scripts depend on it).
Pass `--pretty` for a table-style view of the same result:

```bash
runspecimen --pretty doctor --workspace .
runspecimen status --pretty --workspace . --campaign-id demo-campaign --run-id run-001
```

`--pretty` does not change exit codes, hashes, or the approval gate. Color is
`--color auto|always|never` (`NO_COLOR` disables auto). For a copy-paste first
run: `runspecimen quickstart`.

## What is the eval fast path?

An opt-in exact-match step on `runspecimen eval` that can finish a configured
phrase (`thank you`, `ok`, …) for an explicit `text_completion` task without
calling that task's provider. It does not pass requirement checks, approve a
run, or count a model call unless the skipped task was a model judgment. See
[FASTPATH.md](FASTPATH.md). Disabled unless you add a `fastpath` block or
`fastpath_config`.

## Can agents approve runs?

**Not through the app.** Codex/Cursor plugins and the narrow adapter
(`about`, `dashboard`, `doctor`, `validate`, `status`, `preflight`, `run`, `postflight`,
`verify`) deliberately exclude `approve`. A human must run
`runspecimen approve --workspace … --contract …` in a real terminal.

RunSpecimen stops agents from approving through the app and makes planted or
edited approvals show up as broken receipts. A program running as you that can
edit RunSpecimen's files can still add a fake approval to the record. Signing
with a key the agent can't access lets you check afterwards that a receipt is
authentic, when a signature is required and checked; it does not stop a program
running as you from adding a fake approval or running the job.

## Why does verify fail after I clone the repo?

CLI `verify` rehashes **live** contract bytes, source, outputs, and **runtime**
(resolved interpreter/executable on this machine). Showcase receipts and any
certificate that bound another host’s Python binary will fail until you refresh
on the new host (`python3 scripts/refresh_showcase.py` for the example, or a
full approve → run → postflight path). Also remember: contract hash is raw
file bytes—line endings or whitespace edits change it.

## Can I run two jobs in parallel?

**Not in the same workspace.** One exclusive `fcntl` lease covers the whole
workspace for `approve` / `preflight` / `run` / `postflight`, regardless of
`campaign_id` or `run_id`. Use separate workspaces (separate lease domains) if
you need concurrency. There is no built-in worker pool or scheduler.

## Is the hash chain a signature?

**No.** Events and certificates are SHA-256 hash-chained and locally
recomputable. They detect planted or edited `approval.json` files and casual
tampering of the evidence set. The chain is unkeyed: a program running as you
that can edit RunSpecimen's files can still add a fake approval to the record.
Signing with a key the agent can't access lets you check afterwards that a
receipt is authentic, when a signature is required and checked
(`verify-signature` with an out-of-reach key, or an installed holder —
fail-closed under D1/D2); it does not stop a program running as you from
adding a fake approval or running the job.

The default `sign` command provides HMAC-SHA256 authentication (a shared-secret
Message Authentication Code), not digital signatures. Anyone with the key
can both verify and forge authenticated certificates. Optional Ed25519 signing
(`pip install 'runspecimen[ed25519]'`, `--scheme ed25519`) enables offline
public-key verification without sharing the private key; trusted success still
requires an externally trusted public key (not a key embedded only in the
receipt). See [ED25519_RECEIPTS.md](ED25519_RECEIPTS.md). Soft keys on disk are
not absolute non-repudiation, and Ed25519 is not an OS sandbox.

## How do I integrate with my research script?

Point `argv` at your interpreter and script (`shell=False`), put code and
material inputs under `source.roots`, declare outputs and postflight
assertions, use a fresh `run_id` per attempt, and chain steps with
`predecessor` when needed. See [USER_GUIDE.md](USER_GUIDE.md#integrating-a-research-script).

## Where is the GitHub repo / what version am I on?

- Repository: https://github.com/darashkevich/runspecimen
- Check installed CLI: `runspecimen --version` (engine package version, e.g.
  `0.2.0rc14`, also the published PyPI pin)

## Why does `runspecimen --version` show an older build than Homebrew?

`~/.local/bin` often precedes `/opt/homebrew/bin` on `PATH`. An old pip or
dev install leaves a `~/.local/bin/runspecimen` shim that **shadows** Homebrew’s
`/opt/homebrew/bin/runspecimen`, so `which runspecimen` and plugins that call
the CLI can keep an obsolete build (for example rc11) while brew has
`0.2.0rc14`.

Check:

```bash
which -a runspecimen
runspecimen --version
brew --prefix runspecimen 2>/dev/null; ls -la "$(brew --prefix)/bin/runspecimen" 2>/dev/null
```

Prefer one install path. For the published bottle/sdist pin:

```bash
brew tap darashkevich/runspecimen
brew install darashkevich/runspecimen/runspecimen
```

Then retire the obsolete user shim **by rename/backup** (do not delete other
files under `~/.local`):

```bash
mv ~/.local/bin/runspecimen ~/.local/bin/runspecimen.bak-shadow
hash -r
which runspecimen
runspecimen --version
```

Plugins (Cursor / Codex / Claude / Grok) resolve whatever `runspecimen` is first
on that environment’s `PATH` — fix the CLI install before debugging the adapter.

## Is the dashboard safe to leave open?

It listens on **loopback only** (`127.0.0.1`), has no remote service or
telemetry, and is **read-only** (no approve/run APIs). It still exposes local
run evidence to anything that can reach that port on your machine—treat it like
other localhost debug UIs. It **blocks** the foreground shell; background or
detach it so approval and lifecycle commands stay usable. It does not replace
TTY approval. A certificate shown as issued is recorded history only—the
dashboard never marks live verification green; run `runspecimen verify` in a
terminal.

## How do contract and receipt versions work?

Contracts require `"version": 1`. Receipts may omit `schema_version` (legacy v1)
or set `"schema_version": 1`. Unknown versions fail closed. See
[SCHEMA_COMPATIBILITY.md](SCHEMA_COMPATIBILITY.md).

## HMAC vs Ed25519 — what do authenticated receipts prove?

- **HMAC** (`keygen` / `sign` default): shared-secret MAC. Anyone with the key can
  forge. Useful for controlled sharing, not independent third-party trust.
- **Ed25519** (optional `pip install 'runspecimen[ed25519]'`, `--scheme ed25519`):
  offline public-key verification without sharing the private key. Trusted
  success requires an external trust anchor (`--public-key` or workspace
  `--key-id`); a public key embedded only in the receipt proves consistency,
  not trust. Soft-key custody ≠ absolute non-repudiation; not scientific proof;
  not a sandbox. See [ED25519_RECEIPTS.md](ED25519_RECEIPTS.md).
