rootProject.name = "runspecimen-intellij"
