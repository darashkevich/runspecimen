#!/usr/bin/env python3
"""Narrow adapter for agent hosts; interactive approval intentionally excluded."""

from __future__ import annotations

import argparse
import shutil
import subprocess
from pathlib import Path


ALLOWED = frozenset({
    "about",
    "dashboard",
    "doctor",
    "validate",
    "status",
    "preflight",
    "run",
    "postflight",
    "verify",
    "decisions_search",
    "requirements_report",
    "freshness_check",
})


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=sorted(ALLOWED))
    parser.add_argument("--workspace", type=Path)
    parser.add_argument("--contract", type=Path)
    parser.add_argument("--campaign-id")
    parser.add_argument("--run-id")
    parser.add_argument("--open", action="store_true")
    parser.add_argument("--query", default="")
    parser.add_argument("--manifest", type=Path)
    args = parser.parse_args()

    executable = shutil.which("runspecimen")
    if executable is None:
        parser.error("runspecimen is not installed on PATH")
    if args.action == "about":
        if args.workspace is not None or args.contract is not None or args.campaign_id or args.run_id or args.open:
            parser.error("about takes no workspace/contract/open flags")
        return subprocess.run([executable, "about"], check=False).returncode
    if args.workspace is None:
        parser.error("--workspace is required")
    ws = str(args.workspace.resolve())
    if args.action == "decisions_search":
        command = [executable, "decisions", "search", "--workspace", ws, "--query", args.query]
    elif args.action == "requirements_report":
        if not args.campaign_id or not args.run_id:
            parser.error("requirements_report requires --campaign-id and --run-id")
        command = [
            executable,
            "requirements",
            "report",
            "--workspace",
            ws,
            "--campaign-id",
            args.campaign_id,
            "--run-id",
            args.run_id,
        ]
    elif args.action == "freshness_check":
        if args.contract is None:
            parser.error("freshness_check requires --contract")
        command = [
            executable,
            "freshness",
            "check",
            "--workspace",
            ws,
            "--contract",
            str(args.contract.resolve()),
        ]
        if args.manifest is not None:
            command.extend(["--manifest", str(args.manifest.resolve())])
    else:
        command = [executable, args.action, "--workspace", ws]
        if args.contract is not None:
            command.extend(["--contract", str(args.contract.resolve())])
        if args.campaign_id is not None:
            command.extend(["--campaign-id", args.campaign_id])
        if args.run_id is not None:
            command.extend(["--run-id", args.run_id])
        if args.open:
            if args.action != "dashboard":
                parser.error("--open is supported only for dashboard")
            command.append("--open")
    return subprocess.run(command, check=False).returncode


if __name__ == "__main__":
    raise SystemExit(main())
