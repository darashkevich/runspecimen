"""JSON contract schema and validation."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from runspecimen.errors import ContractError, PathEscapeError
from runspecimen.hashutil import hash_contract_file, sha256_bytes
from runspecimen.paths import ensure_within, resolve_workspace, validate_id
from runspecimen.schema import assert_supported_contract_version
from runspecimen.terminaltext import UNSAFE_DISPLAY_REFUSAL, has_unsafe_display_chars

# Hard caps enforced by the tool (unsafe if contract exceeds these).
MAX_WALL_TIMEOUT_SEC = 24 * 60 * 60
MAX_CAPTURE_BYTES = 50 * 1024 * 1024
MAX_APPROVAL_TTL_SEC = 7 * 24 * 60 * 60
MIN_WALL_TIMEOUT_SEC = 1
MIN_CAPTURE_BYTES = 1
MIN_APPROVAL_TTL_SEC = 1
MAX_CONTRACT_BYTES = 1 * 1024 * 1024
MAX_STRING_CHARS = 16 * 1024
MAX_ARGV_LEN = 256

_HEX_CHARS = set("0123456789abcdefABCDEF")


def _reject_unknown(obj: dict[str, Any], allowed: set[str], label: str) -> None:
    unknown = sorted(set(obj) - allowed)
    if unknown:
        raise ContractError(f"{label} contains unknown field(s): {', '.join(unknown)}")


def _object_without_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ContractError(f"duplicate JSON field: {key!r}")
        result[key] = value
    return result


def _require_dict(obj: Any, label: str) -> dict[str, Any]:
    if not isinstance(obj, dict):
        raise ContractError(f"{label} must be an object")
    return obj


def _require_id(obj: Any, label: str) -> str:
    value = _require_str(obj, label)
    try:
        return validate_id(value)
    except PathEscapeError as exc:
        raise ContractError(f"{label} is not a path-safe id: {exc}") from exc


def _refuse_display_controls(value: str, label: str) -> None:
    """Refuse C0/C1/DEL/bidi/format characters in contract strings.

    Display code also escapes these (defence in depth) so a TTY cannot be
    rewritten if a value ever reaches approve review or pretty output.
    """
    if has_unsafe_display_chars(value):
        raise ContractError(f"{label} {UNSAFE_DISPLAY_REFUSAL}")


def _require_str(obj: Any, label: str) -> str:
    if not isinstance(obj, str) or not obj:
        raise ContractError(f"{label} must be a non-empty string")
    if "\x00" in obj:
        raise ContractError(f"{label} must not contain NUL bytes")
    _refuse_display_controls(obj, label)
    if len(obj) > MAX_STRING_CHARS:
        raise ContractError(
            f"{label} exceeds max length {MAX_STRING_CHARS} characters"
        )
    return obj


def _require_int(obj: Any, label: str) -> int:
    if isinstance(obj, bool) or not isinstance(obj, int):
        raise ContractError(f"{label} must be an integer")
    return obj


def _require_bool(obj: Any, label: str) -> bool:
    if not isinstance(obj, bool):
        raise ContractError(f"{label} must be a JSON boolean (true/false), not {type(obj).__name__}")
    return obj


def _require_list(obj: Any, label: str) -> list[Any]:
    if not isinstance(obj, list):
        raise ContractError(f"{label} must be an array")
    return obj


def _require_sha256_hex(obj: Any, label: str) -> str:
    if not isinstance(obj, str) or len(obj) != 64:
        raise ContractError(f"{label} must be a 64-character SHA-256 hex digest")
    if any(c not in _HEX_CHARS for c in obj):
        raise ContractError(f"{label} must be hexadecimal")
    return obj.lower()


@dataclass(frozen=True)
class SourceSpec:
    roots: tuple[str, ...]
    excludes: tuple[str, ...]


@dataclass(frozen=True)
class CapsSpec:
    wall_timeout_sec: int
    stdout_max_bytes: int
    stderr_max_bytes: int


@dataclass(frozen=True)
class ApprovalSpec:
    ttl_sec: int


@dataclass(frozen=True)
class RuntimeSpec:
    """Runtime provenance configuration in contract."""
    env_allowlist: tuple[str, ...]  # Environment variables to capture and bind
    interpreter: str | None  # Optional interpreter path (auto-detected if None)
    capture_libs: bool  # Whether to capture linked library hashes


@dataclass(frozen=True)
class PredecessorSpec:
    campaign_id: str
    run_id: str
    require_postflight: bool = True
    refuse_if_failed: bool = True


@dataclass(frozen=True)
class JsonEqualsAssert:
    path: str
    field: str
    equals: Any


@dataclass(frozen=True)
class PostflightSpec:
    exit_code: int
    require_outputs: bool
    output_sha256: dict[str, str]
    json_equals: tuple[JsonEqualsAssert, ...]
    source_unchanged: bool


@dataclass(frozen=True)
class IsolationSpec:
    """Opt-in confinement. ``none`` is the default and confines nothing."""

    backend: str
    network: bool = False


@dataclass(frozen=True)
class PolicyRef:
    """Workspace-local shared policy. The file bytes are part of the contract hash."""

    id: str
    path: str
    sha256: str


@dataclass(frozen=True)
class TaskManifestRef:
    """Optional bound task manifest. Bytes are part of the contract hash."""

    id: str
    path: str
    sha256: str


@dataclass(frozen=True)
class Contract:
    version: int
    campaign_id: str
    run_id: str
    argv: tuple[str, ...]
    cwd: str
    source: SourceSpec
    outputs_required: tuple[str, ...]
    caps: CapsSpec
    approval: ApprovalSpec
    predecessor: PredecessorSpec | None
    postflight: PostflightSpec
    runtime: RuntimeSpec | None
    isolation: IsolationSpec
    policy: PolicyRef | None
    task_manifest: TaskManifestRef | None
    path: Path
    contract_hash: str
    raw: dict[str, Any] = field(repr=False)
    execution_approval: str | None = None


    @property
    def asserted_output_paths(self) -> tuple[str, ...]:
        """Every file whose contents or existence influence postflight."""
        paths = set(self.outputs_required)
        paths.update(self.postflight.output_sha256)
        paths.update(assertion.path for assertion in self.postflight.json_equals)
        return tuple(sorted(paths))


_ISOLATION_BACKENDS = frozenset({"none", "sandbox-exec", "bwrap"})


def _parse_isolation(raw: Any) -> IsolationSpec:
    if raw is None:
        return IsolationSpec(backend="none", network=False)
    obj = _require_dict(raw, "isolation")
    _reject_unknown(obj, {"backend", "network"}, "isolation")
    backend = obj.get("backend", "none")
    if not isinstance(backend, str) or backend not in _ISOLATION_BACKENDS:
        raise ContractError(
            "isolation.backend must be one of: none, sandbox-exec, bwrap"
        )
    if "network" in obj:
        network = _require_bool(obj.get("network"), "isolation.network")
    else:
        network = False
    if backend == "none" and network:
        raise ContractError(
            "isolation.network cannot be enabled when backend is none; "
            "none does not confine the network"
        )
    return IsolationSpec(backend=backend, network=network)


_EXECUTION_APPROVALS = frozenset({"local", "companion", "dual"})


def _parse_execution_approval(raw: Any) -> str | None:
    """Biometric execution policy. Absent keeps the typed-phrase gate."""
    if raw is None:
        return None
    value = _require_str(raw, "execution_approval")
    if value not in _EXECUTION_APPROVALS:
        raise ContractError(
            "execution_approval must be local, companion, or dual"
        )
    return value


def _parse_policy(raw: Any) -> PolicyRef | None:
    if raw is None:
        return None
    obj = _require_dict(raw, "policy")
    _reject_unknown(obj, {"id", "path", "sha256"}, "policy")
    policy_id = _require_str(obj.get("id"), "policy.id")
    if any(ch.isspace() for ch in policy_id) or "/" in policy_id or "\\" in policy_id:
        raise ContractError("policy.id must be a single token without path separators")
    path = _require_str(obj.get("path"), "policy.path")
    if path.startswith("/") or path.startswith("~"):
        raise ContractError("policy.path must be a relative path inside the workspace")
    digest = _require_sha256_hex(obj.get("sha256"), "policy.sha256")
    return PolicyRef(id=policy_id, path=path, sha256=digest)


def _parse_task_manifest_ref(raw: Any) -> TaskManifestRef | None:
    if raw is None:
        return None
    obj = _require_dict(raw, "task_manifest")
    _reject_unknown(obj, {"id", "path", "sha256"}, "task_manifest")
    mid = _require_str(obj.get("id"), "task_manifest.id")
    if any(ch.isspace() for ch in mid) or "/" in mid or "\\" in mid:
        raise ContractError(
            "task_manifest.id must be a single token without path separators"
        )
    path = _require_str(obj.get("path"), "task_manifest.path")
    if path.startswith("/") or path.startswith("~"):
        raise ContractError(
            "task_manifest.path must be a relative path inside the workspace"
        )
    digest = _require_sha256_hex(obj.get("sha256"), "task_manifest.sha256")
    return TaskManifestRef(id=mid, path=path, sha256=digest)


def validate_caps(caps: CapsSpec) -> None:
    if not (MIN_WALL_TIMEOUT_SEC <= caps.wall_timeout_sec <= MAX_WALL_TIMEOUT_SEC):
        raise ContractError(
            f"unsafe wall_timeout_sec={caps.wall_timeout_sec} "
            f"(allowed {MIN_WALL_TIMEOUT_SEC}..{MAX_WALL_TIMEOUT_SEC})"
        )
    if not (MIN_CAPTURE_BYTES <= caps.stdout_max_bytes <= MAX_CAPTURE_BYTES):
        raise ContractError(
            f"unsafe stdout_max_bytes={caps.stdout_max_bytes} "
            f"(allowed {MIN_CAPTURE_BYTES}..{MAX_CAPTURE_BYTES})"
        )
    if not (MIN_CAPTURE_BYTES <= caps.stderr_max_bytes <= MAX_CAPTURE_BYTES):
        raise ContractError(
            f"unsafe stderr_max_bytes={caps.stderr_max_bytes} "
            f"(allowed {MIN_CAPTURE_BYTES}..{MAX_CAPTURE_BYTES})"
        )


def parse_contract(
    data: dict[str, Any], *, path: Path, contract_hash: str | None = None
) -> Contract:
    data = _require_dict(data, "contract")
    _reject_unknown(
        data,
        {
            "version",
            "campaign_id",
            "run_id",
            "argv",
            "cwd",
            "source",
            "outputs",
            "caps",
            "approval",
            "predecessor",
            "postflight",
            "runtime",
            "isolation",
            "policy",
            "task_manifest",
            "execution_approval",
        },
        "contract",
    )
    version = _require_int(data.get("version"), "version")
    assert_supported_contract_version(version)

    campaign_id = _require_id(data.get("campaign_id"), "campaign_id")
    run_id = _require_id(data.get("run_id"), "run_id")

    argv_raw = _require_list(data.get("argv"), "argv")
    if not argv_raw:
        raise ContractError("argv must be a non-empty array")
    if len(argv_raw) > MAX_ARGV_LEN:
        raise ContractError(f"argv exceeds max length {MAX_ARGV_LEN}")
    argv: list[str] = []
    for i, item in enumerate(argv_raw):
        if not isinstance(item, str) or item == "":
            raise ContractError(f"argv[{i}] must be a non-empty string")
        # Preferred refuse point for terminal-control injection in argv
        # (CC-01). Display still escapes as defence in depth.
        if "\x00" in item:
            raise ContractError(f"argv[{i}] must not contain NUL bytes")
        _refuse_display_controls(item, f"argv[{i}]")
        argv.append(item)

    cwd = _require_str(data.get("cwd", "."), "cwd")

    source_obj = _require_dict(data.get("source"), "source")
    _reject_unknown(source_obj, {"roots", "excludes"}, "source")
    roots_raw = _require_list(source_obj.get("roots"), "source.roots")
    if not roots_raw:
        raise ContractError("source.roots must be non-empty")
    roots = tuple(_require_str(r, f"source.roots[{i}]") for i, r in enumerate(roots_raw))
    excludes_raw = source_obj.get("excludes", [])
    excludes_list = _require_list(excludes_raw, "source.excludes")
    excludes = tuple(
        _require_str(x, f"source.excludes[{i}]") for i, x in enumerate(excludes_list)
    )

    outputs_obj = _require_dict(data.get("outputs"), "outputs")
    _reject_unknown(outputs_obj, {"required"}, "outputs")
    req_raw = _require_list(outputs_obj.get("required"), "outputs.required")
    outputs_required = tuple(
        _require_str(x, f"outputs.required[{i}]") for i, x in enumerate(req_raw)
    )

    caps_obj = _require_dict(data.get("caps"), "caps")
    _reject_unknown(
        caps_obj,
        {"wall_timeout_sec", "stdout_max_bytes", "stderr_max_bytes"},
        "caps",
    )
    caps = CapsSpec(
        wall_timeout_sec=_require_int(caps_obj.get("wall_timeout_sec"), "caps.wall_timeout_sec"),
        stdout_max_bytes=_require_int(caps_obj.get("stdout_max_bytes"), "caps.stdout_max_bytes"),
        stderr_max_bytes=_require_int(caps_obj.get("stderr_max_bytes"), "caps.stderr_max_bytes"),
    )
    validate_caps(caps)

    approval_obj = _require_dict(data.get("approval"), "approval")
    _reject_unknown(approval_obj, {"ttl_sec"}, "approval")
    ttl = _require_int(approval_obj.get("ttl_sec"), "approval.ttl_sec")
    if not (MIN_APPROVAL_TTL_SEC <= ttl <= MAX_APPROVAL_TTL_SEC):
        raise ContractError(
            f"unsafe approval.ttl_sec={ttl} "
            f"(allowed {MIN_APPROVAL_TTL_SEC}..{MAX_APPROVAL_TTL_SEC})"
        )
    approval = ApprovalSpec(ttl_sec=ttl)

    pred_raw = data.get("predecessor")
    predecessor: PredecessorSpec | None
    if pred_raw is None:
        predecessor = None
    else:
        pred = _require_dict(pred_raw, "predecessor")
        _reject_unknown(
            pred,
            {"campaign_id", "run_id", "require_postflight", "refuse_if_failed"},
            "predecessor",
        )
        if "require_postflight" in pred:
            require_postflight = _require_bool(pred.get("require_postflight"), "predecessor.require_postflight")
        else:
            require_postflight = True
        if "refuse_if_failed" in pred:
            refuse_if_failed = _require_bool(pred.get("refuse_if_failed"), "predecessor.refuse_if_failed")
        else:
            refuse_if_failed = True
        predecessor = PredecessorSpec(
            campaign_id=_require_id(
                pred.get("campaign_id", campaign_id), "predecessor.campaign_id"
            ),
            run_id=_require_id(pred.get("run_id"), "predecessor.run_id"),
            require_postflight=require_postflight,
            refuse_if_failed=refuse_if_failed,
        )
        if not predecessor.require_postflight or not predecessor.refuse_if_failed:
            raise ContractError(
                "predecessor.require_postflight and predecessor.refuse_if_failed "
                "must both be true (v1 mandatory-gating promise)"
            )

    pf_obj = _require_dict(data.get("postflight"), "postflight")
    _reject_unknown(
        pf_obj,
        {"exit_code", "require_outputs", "output_sha256", "json_equals", "source_unchanged"},
        "postflight",
    )
    exit_code = _require_int(pf_obj.get("exit_code"), "postflight.exit_code")
    if "require_outputs" in pf_obj:
        require_outputs = _require_bool(pf_obj.get("require_outputs"), "postflight.require_outputs")
    else:
        require_outputs = True
    sha_obj = pf_obj.get("output_sha256", {})
    sha_dict = _require_dict(sha_obj, "postflight.output_sha256")
    output_sha256: dict[str, str] = {}
    for k, v in sha_dict.items():
        if not isinstance(k, str) or not k:
            raise ContractError("postflight.output_sha256 keys must be non-empty paths")
        output_sha256[k] = _require_sha256_hex(v, f"postflight.output_sha256[{k!r}]")
    je_raw = pf_obj.get("json_equals", [])
    je_list = _require_list(je_raw, "postflight.json_equals")
    json_equals: list[JsonEqualsAssert] = []
    for i, item in enumerate(je_list):
        item_d = _require_dict(item, f"postflight.json_equals[{i}]")
        _reject_unknown(
            item_d,
            {"path", "field", "equals"},
            f"postflight.json_equals[{i}]",
        )
        if "equals" not in item_d:
            raise ContractError(f"postflight.json_equals[{i}].equals is required")
        json_equals.append(
            JsonEqualsAssert(
                path=_require_str(item_d.get("path"), f"postflight.json_equals[{i}].path"),
                field=_require_str(item_d.get("field"), f"postflight.json_equals[{i}].field"),
                equals=item_d.get("equals"),
            )
        )
    # v1 provenance promise: source_unchanged must be present and true.
    source_unchanged = _require_bool(pf_obj.get("source_unchanged"), "postflight.source_unchanged")
    if source_unchanged is not True:
        raise ContractError(
            "postflight.source_unchanged must be true (v1 exact-provenance promise)"
        )
    postflight = PostflightSpec(
        exit_code=exit_code,
        require_outputs=require_outputs,
        output_sha256=output_sha256,
        json_equals=tuple(json_equals),
        source_unchanged=source_unchanged,
    )

    # Parse optional runtime provenance configuration
    runtime_raw = data.get("runtime")
    runtime_spec: RuntimeSpec | None = None
    if runtime_raw is not None:
        rt = _require_dict(runtime_raw, "runtime")
        _reject_unknown(rt, {"env_allowlist", "interpreter", "capture_libs"}, "runtime")

        env_allowlist_raw = rt.get("env_allowlist", [])
        env_allowlist_list = _require_list(env_allowlist_raw, "runtime.env_allowlist")
        env_allowlist = tuple(
            _require_str(x, f"runtime.env_allowlist[{i}]")
            for i, x in enumerate(env_allowlist_list)
        )

        interpreter = rt.get("interpreter")
        if interpreter is not None:
            interpreter = _require_str(interpreter, "runtime.interpreter")

        capture_libs = rt.get("capture_libs", False)
        if capture_libs is not None:
            capture_libs = _require_bool(capture_libs, "runtime.capture_libs")

        runtime_spec = RuntimeSpec(
            env_allowlist=env_allowlist,
            interpreter=interpreter,
            capture_libs=capture_libs or False,
        )

    isolation = _parse_isolation(data.get("isolation"))
    policy = _parse_policy(data.get("policy"))
    task_manifest = _parse_task_manifest_ref(data.get("task_manifest"))
    execution_approval = _parse_execution_approval(data.get("execution_approval"))

    if contract_hash is None:
        contract_hash = hash_contract_file(path)
    return Contract(
        version=version,
        campaign_id=campaign_id,
        run_id=run_id,
        argv=tuple(argv),
        cwd=cwd,
        source=SourceSpec(roots=roots, excludes=excludes),
        outputs_required=outputs_required,
        caps=caps,
        approval=approval,
        predecessor=predecessor,
        postflight=postflight,
        runtime=runtime_spec,
        isolation=isolation,
        policy=policy,
        task_manifest=task_manifest,
        path=path.resolve(),
        contract_hash=contract_hash,
        raw=data,
        execution_approval=execution_approval,
    )


def load_contract(path: Path) -> Contract:
    path = path.expanduser().resolve()
    if not path.is_file():
        raise ContractError(f"contract not found: {path}")
    try:
        # Parse and fingerprint one snapshot. Reopening the path to hash it
        # could bind the parsed command to a replacement contract's bytes.
        payload = path.read_bytes()
        if len(payload) > MAX_CONTRACT_BYTES:
            raise ContractError(
                f"contract exceeds max size {MAX_CONTRACT_BYTES} bytes"
            )
        try:
            text = payload.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ContractError(f"invalid contract JSON encoding: {exc}") from exc
        data = json.loads(text, object_pairs_hook=_object_without_duplicates)
        if not isinstance(data, dict):
            raise ContractError("contract must be a JSON object")
    except ContractError:
        raise
    except json.JSONDecodeError as exc:
        raise ContractError(f"invalid contract JSON: {exc}") from exc
    except Exception as exc:  # noqa: BLE001
        raise ContractError(f"invalid contract JSON: {exc}") from exc
    return parse_contract(data, path=path, contract_hash=sha256_bytes(payload))


def check_contract_paths(contract: Contract, workspace: Path) -> None:
    """Ensure cwd, source roots, and output paths stay inside workspace."""
    workspace = resolve_workspace(workspace)
    ensure_within(workspace, Path(contract.cwd), label="cwd")
    for root in contract.source.roots:
        ensure_within(workspace, Path(root), label=f"source root {root!r}")
    for out in contract.outputs_required:
        ensure_within(workspace, Path(out), label=f"output {out!r}")
    for out in contract.postflight.output_sha256:
        ensure_within(workspace, Path(out), label=f"output_sha256 path {out!r}")
    for assertion in contract.postflight.json_equals:
        ensure_within(workspace, Path(assertion.path), label=f"json_equals path {assertion.path!r}")
    if contract.policy is not None:
        ensure_within(workspace, Path(contract.policy.path), label="policy.path")
    if contract.task_manifest is not None:
        ensure_within(
            workspace, Path(contract.task_manifest.path), label="task_manifest.path"
        )
